# Paso 5. Implementación CUDA Python

Estado: **en curso; no hay resultados GPU aceptados todavía**.
Fuente absoluta: Proyecto 3 CUDA.pdf, páginas 2–3. REQ-06/07/09/12;
CAM-006; BIT-008; DEC-021. El notebook original se conserva intacto.

## Revisión del diseño antes de implementar

Por indicación posterior del usuario, no se repite la campaña CPU completa.
Se reutilizará la fase CNN-B de las cinco corridas EXP-002 siempre que coincidan
datos, arquitectura, batch128,15 épocas, último lote20 y frontera temporal con
validación incluida. Las nuevas mediciones GPU tendrán otro EXP, sin alterar
configuración ni evidencias CPU. La comparación con una referencia histórica
no alternada debe explicitar ese límite de condiciones térmicas/temporales.

Se retira la obligación de nuevas máscaras exactamente iguales a CPU histórica.
Para timing basta mismo Dropout/distribución y volumen; para pruebas unitarias
se usan máscaras fijas pequeñas. No se elimina Dropout ni se fuerza determinismo
numérico completo como requisito para reutilizar la carga CPU. Los cambios de
diseño y entorno se registran antes de medir; no se comparan cargas distintas.

Se utilizará PCUDA y el dataset cacheado, sin reinstalar sus paquetes existentes.
La inspección encuentra toolkit CUDA13.1 local y GPU sm_75. El perfil12.x propuesto
se adapta al toolkit existente para evitar descargas innecesarias. Solo faltan
las dependencias CUDA Python/Numba; su resolución preliminar admite NumPy2.5.5.
Antes de entrenar se requiere prueba real de compilación/ejecución y corrección.

Los resultados de compatibilidad, ensayos, corrección y medición se incorporarán
al completar la actividad, distinguiendo cada estado y conservando errores.
